SELECT product_name, list_price, date_added
FROM products
ORDER BY product_name